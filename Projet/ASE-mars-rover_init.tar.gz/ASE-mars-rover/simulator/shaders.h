void init_shaders(void);
